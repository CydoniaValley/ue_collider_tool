import bpy
import bmesh
from mathutils import Vector
#Dev
# import ct_functions
# import ct_material
#Addon
from . import ct_functions
from . import ct_material


def calc_center(v_lst):
    min_v = min(v_lst)
    max_v = max(v_lst)
    dist = max_v - min_v
    av = (min_v + max_v) / 2
    return dist, av

def upd_object_mode(act_obj):
    p = bpy.context.scene.ct_props
    dims = bpy.context.active_object.dimensions
    #print("Dimensions:  ", dims)
    max_dim = max(dims)
    #print("Max Dimension:  ", max_dim)
    print("Sphere Diameter: ", max_dim)
    loc_obj_center = 0.125 * sum((Vector(b) for b in act_obj.bound_box), Vector())
    world_obj_center = act_obj.matrix_world @ loc_obj_center
    sph_radius = max_dim / 2 + p.collider_offset
    
    return sph_radius, world_obj_center


def upd_edit_mode(act_obj):
    
    p = bpy.context.scene.ct_props
    lst_x = []
    lst_y = []
    lst_z = []
    bm = bmesh.new()
    bm = bmesh.from_edit_mesh(act_obj.data)

    
    for v in bm.verts:
        if v.select == True:
            lst_x.append(v.co.x)
            lst_y.append(v.co.y)
            lst_z.append(v.co.z)
            
    rel_x = calc_center(lst_x)
    rel_y = calc_center(lst_y)
    rel_z = calc_center(lst_z)
            
    print("REL DIST: ", rel_x[0], rel_y[0], rel_z[0])
    
    rel_list = (rel_x[0], rel_y[0], rel_z[0])
    max_width = max(rel_list)
    if max_width < 0.125:
        max_width = 0.25
    print(max_width)
    
    loc_obj_center = Vector((rel_x[1], rel_y[1], rel_z[1]))
    world_obj_center = act_obj.matrix_world @ loc_obj_center
    
    return max_width, world_obj_center
    
 
def build_sphere():
    print("\n* BUILD SPHERE *\n")
    act_obj = bpy.context.active_object
    # Make sure there is an object selected and it is a Mesh
    if act_obj is not None and act_obj.type == 'MESH':
        p = bpy.context.scene.ct_props
        
        # sort colliders based on user options selection
        if p.use_object_name_conv:
            soco = ct_functions.sort_colliders(act_obj.name)
        else:
            soco = ct_functions.sort_colliders(p.root_name)
            
        suffix_config = str(soco[1]).rjust(p.leading_zeroes, "0")
        name_config = "{}_{}".format(soco[0], suffix_config)
        
        if act_obj.mode == 'EDIT':
            emode = upd_edit_mode(act_obj)
            sph_radius = emode[0] / 2.0
            #sph_z = emode[1]
            world_obj_center = emode[1]
            
            print("Edit Mode: ucp_radius: ", sph_radius)
            print("Edit Mode: world_obj_center: ", world_obj_center)
   
    
        elif act_obj.mode == 'OBJECT':
            omode = upd_object_mode(act_obj)
            sph_radius = omode[0]
            #sph_z = omode[1]
            world_obj_center = omode[1]
            
            #print("Object Mode: sph_radius: ", sph_radius)
            #print("Object Mode: world_obj_center: ", world_obj_center)
            
        bm = bmesh.new()
        bmesh.ops.create_uvsphere(bm, u_segments=16, v_segments=10, radius=sph_radius)
                
        mesh = bpy.data.meshes.new(name_config)
        bm.to_mesh(mesh)
        for f in mesh.polygons:
            f.use_smooth = True
        mesh.update()
        bm.free()

        sph_obj = bpy.data.objects.new(name_config, mesh)
        
        if p.option_parent_collider:
            sph_obj.parent = act_obj
            sph_obj.matrix_parent_inverse = act_obj.matrix_world.inverted()
            

        loc_act_obj = bpy.data.objects[act_obj.name].location
        #rot_act_obj = bpy.data.objects[act_obj.name].rotation_euler
        #scale_act_obj = bpy.data.objects[act_obj.name].scale
        
        sph_obj.location = world_obj_center
        #ucp_obj.location = loc_act_obj
        #sph_obj.rotation_euler = rot_act_obj
        #sph_obj.scale = scale_act_obj
        
        if act_obj.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
            
        bpy.context.scene.collection.children[p.collection_name].objects.link(sph_obj)
        
        for so in bpy.context.view_layer.objects.selected:
            so.select_set(False)
        if p.select_created_collider:
            bpy.context.view_layer.objects.active = sph_obj
            sph_obj.select_set(True)
        else:
            bpy.context.view_layer.objects.active = sph_obj
            act_obj.select_set(True)
            
        bpy.context.view_layer.update()
        bpy.context.view_layer.objects.active = sph_obj
        ct_material.assign_material(sph_obj)
        print()
        print("Sphere Collider Created")
    
    else:
        print("Something went wrong building Sphere!")