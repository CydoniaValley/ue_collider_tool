import bpy
import bmesh
from mathutils import Vector

#Dev
# import ct_functions
# import ct_material

#Addon
from . import ct_functions
from . import ct_material
    
def duplicate_to_convexhull():
    act_obj = bpy.context.active_object
    bpy.ops.object.duplicate()
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.convex_hull()
    bpy.ops.object.mode_set(mode="OBJECT")
    sel_objs = bpy.context.selected_objects
    #bpy.context.view_layer.objects.active = sel_objs[0]
    return sel_objs[0]
    

def build_convex_hull():
    print("\n* BUILD CONVEX HULL *\n")
    
    orig_obj = bpy.context.active_object
    
    hull_obj = duplicate_to_convexhull()
    #print("hull_obj: ", hull_obj)
    
    p = bpy.context.scene.ct_props
    bpy.context.scene.collection.children[p.collection_name].objects.link(hull_obj)

    total_verts = 0
    
    dgraph = bpy.context.evaluated_depsgraph_get()
    bm = bmesh.new()
    bm.from_object(hull_obj, dgraph, face_normals=False)
    total_verts = len(bm.verts)
    #print("Total Vertices (bmesh): ", total_verts)
    bm.free()
    del bm

#    #p.decimate_rate
#    #p.create_dec_modifier

#    p = bpy.context.scene.ct_props
    sel_axis = 'X'
    if p.x_hull_sym or p.y_hull_sym or p.z_hull_sym:
        sel_sym = True
    else:
        sel_sym = False
    if p.x_hull_sym:
        sel_axis = 'X'
    if p.y_hull_sym:
        sel_axis = 'Y'
    if p.z_hull_sym:
        sel_axis = 'Z'
    
    if total_verts > 3 and total_verts < 25:
        dec_rate = 1.0
    elif total_verts > 24 and total_verts < 300:
        dec_rate = 0.825
        dec_rate = dec_rate * p.decimate_rate
    elif total_verts > 299 and total_verts < 1000:
        dec_rate = 0.5
        dec_rate = dec_rate * p.decimate_rate
    elif total_verts > 999 and total_verts < 5000:
        dec_rate = 0.25
        dec_rate = dec_rate * p.decimate_rate
    else:
        dec_rate = 0.125
        dec_rate = dec_rate * p.decimate_rate
    
    
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.decimate(ratio=dec_rate, use_symmetry=sel_sym, symmetry_axis = sel_axis)
    bpy.ops.object.mode_set(mode="OBJECT")
    
    print("Uses Symmetry:", sel_sym, "  Symmetry Axis:", sel_axis)
    print("Final Hull Decimate Ratio:", dec_rate)
    
    if p.use_object_name_conv:
        soco = ct_functions.sort_colliders(hull_obj.name)
    else:
        soco = ct_functions.sort_colliders(p.root_name)
        
    suffix_config = str(soco[1]).rjust(p.leading_zeroes, "0")
    name_config = "{}_{}".format(soco[0], suffix_config)
    
    hull_obj.name = name_config
    hull_obj.data.materials.clear()
    
    ct_material.assign_material(hull_obj)
    
    if p.option_parent_collider:
        hull_obj.parent = orig_obj
        #sph_obj.matrix_parent_inverse = act_obj.matrix_world.inverted()
        
    print("Convex Hull Collider Created")