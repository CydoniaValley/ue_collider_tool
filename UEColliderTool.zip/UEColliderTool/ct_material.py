import bpy

def assign_material(obj):
    p = bpy.context.scene.ct_props
    clr_pckr = []
    sx = ""
    
    if p.color_index == 0:
        obj.color = p.sel_color_a[:]
        sx = "_A"
        clr_pckr = p.sel_color_a
    elif p.color_index == 1:
        obj.color = p.sel_color_b[:]
        sx = "_B"
        clr_pckr = p.sel_color_b
    elif p.color_index == 2:
        obj.color = p.sel_color_c[:]
        sx = "_C"
        clr_pckr = p.sel_color_c
    elif p.color_index == 3:
        obj.color = p.sel_color_d[:]
        sx = "_D"
        clr_pckr = p.sel_color_d
        
    mat_name = "{}{}".format(p.material_name, sx)
    
    # Check if the collider material exists, and assign it
    # to collider 'obj' if it does.
    if mat_name in bpy.data.materials:
        assign_mat = bpy.data.materials.get(mat_name)
        obj.data.materials.append(assign_mat)

    # Create a new material since it's not in the material pool
    else:  
        #mat_name not in bpy.data.materials:
        new_mat = bpy.data.materials.new(name=mat_name)
        obj.data.materials.append(new_mat)
        new_mat.use_nodes = True
        new_mat.blend_method = p.blend_mode
        new_mat.show_transparent_back = p.shader_backface
        remove_default = new_mat.node_tree.nodes["Principled BSDF"]
        new_mat.node_tree.nodes.remove(remove_default)

    # Create the shader for the new material
        output_node = new_mat.node_tree.nodes.get("Material Output")
        output_node.location = (200, 0)
        mix_shader = new_mat.node_tree.nodes.new("ShaderNodeMixShader")
        mix_shader.location = (0, 0)
        mix_shader.label = "CT Mix Shader"
        mix_shader.inputs[0].default_value = p.shader_opacity
        gloss_shader = new_mat.node_tree.nodes.new("ShaderNodeBsdfGlossy")
        gloss_shader.location = (-200, 100)
        gloss_shader.label = "CT Glossy BSDF"
        gloss_shader.inputs[1].default_value = p.shader_roughness
        transparent_shader = new_mat.node_tree.nodes.new("ShaderNodeBsdfTransparent")
        transparent_shader.location = (-200, -100)
        invert_node = new_mat.node_tree.nodes.new("ShaderNodeInvert")
        invert_node.location = (-400, -100)
        invert_node.label = "CT Invert"
        invert_node.inputs[0].default_value = p.shader_invert
        wireframe_node = new_mat.node_tree.nodes.new("ShaderNodeWireframe")
        wireframe_node.location = (-600, -100)
        wireframe_node.label = "CT Wireframe"
        wireframe_node.inputs[0].default_value = p.wireframe_size
        rgb_node = new_mat.node_tree.nodes.new("ShaderNodeRGB")
        rgb_node.location = (-500, 200)
        rgb_node.label = "CT RGB"
        rgb_node.outputs[0].default_value = clr_pckr
        
        # Link the nodes together
        nlinks = new_mat.node_tree.links
        nlinks.new(wireframe_node.outputs.get('Fac'), invert_node.inputs.get('Color'))
        nlinks.new(invert_node.outputs.get('Color'), transparent_shader.inputs.get('Color'))
        nlinks.new(gloss_shader.outputs[0], mix_shader.inputs[2])
        nlinks.new(transparent_shader.outputs[0], mix_shader.inputs[1])
        nlinks.new(mix_shader.outputs[0], output_node.inputs[0])
        nlinks.new(rgb_node.outputs[0], gloss_shader.inputs[0])
        
        # Tool for identifying inputs/outputs
#        print([x.identifier for x in transparent_shader.outputs])
#        print([x.identifier for x in mix_shader.inputs])
#        print([x.identifier for x in output_node.inputs])
