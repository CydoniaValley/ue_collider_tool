import bpy
import bmesh
from mathutils import Vector
from math import degrees, pi

#Dev
# import ct_functions
# import ct_material

#Addon
from . import ct_functions
from . import ct_material


def calc_center(v_lst):
    min_v = min(v_lst)
    max_v = max(v_lst)
    dist = max_v - min_v
    av = (min_v + max_v) / 2
    return dist, av

def upd_edit_mode(act_obj):
    print("\n* BUILD CAPSULE *")
    p = bpy.context.scene.ct_props
    lst_x = []
    lst_y = []
    lst_z = []
    bm = bmesh.new()
    bm = bmesh.from_edit_mesh(act_obj.data)
    
    for v in bm.verts:
        if v.select == True:
            lst_x.append(v.co.x)
            lst_y.append(v.co.y)
            lst_z.append(v.co.z)
            
    rel_x = calc_center(lst_x)
    rel_y = calc_center(lst_y)
    rel_z = calc_center(lst_z)
            
#    print("REL DIST: ", rel_x[0], rel_y[0], rel_z[0])
    

    if rel_z[0] > rel_x[0] and rel_z[0] > rel_y[0]:
        if rel_x[0] < rel_y[0]:
            ucp_radius = (rel_x[0] / 2) + p.collider_offset
        else:
            ucp_radius = (rel_y[0] / 2) + p.collider_offset
            
        if ucp_radius < 0.16:
            ucp_radius = 0.16

        ucp_z = ((rel_z[0] - (ucp_radius * 2)) / 2) + p.collider_offset
            
        loc_obj_center = Vector((rel_x[1], rel_y[1], rel_z[1]))
#        print(act_obj.matrix_world)
#        print(loc_obj_center)
        world_obj_center = act_obj.matrix_world @ loc_obj_center
        
        return ucp_radius, ucp_z, world_obj_center
    
    else:
        loc_obj_center = Vector((rel_x[1], rel_y[1], rel_z[1]))
        world_obj_center = act_obj.matrix_world @ loc_obj_center
        
        return 0.2, 0.5, world_obj_center


    
def upd_object_mode(act_obj):
    
    print("\n* BUILD CAPSULE *")
    dims = bpy.context.active_object.dimensions
    if dims.z > dims.x and dims.z > dims.y:
        p = bpy.context.scene.ct_props
        loc_obj_center = 0.125 * sum((Vector(b) for b in act_obj.bound_box), Vector())
        world_obj_center = act_obj.matrix_world @ loc_obj_center
        #print("LOCAL OBJ CENTER:", loc_obj_center)
        #print("WORLD OBJ CENTER:", world_obj_center)
        
        if dims.x < dims.y:
            ucp_radius = (dims.x / 2) + p.collider_offset
        else:
            ucp_radius = (dims.y / 2) + p.collider_offset
        ucp_z = ((dims.z - (ucp_radius * 2)) / 2) + p.collider_offset
        
        return ucp_radius, ucp_z, world_obj_center
    else:
        return "FAIL"

    
def build_capsule(): 

    act_obj = bpy.context.active_object
    
    if act_obj is not None and act_obj.type == 'MESH':
        p = bpy.context.scene.ct_props
            
        # sort colliders based on user options selection
        if p.use_object_name_conv:
            soco = ct_functions.sort_colliders(act_obj.name)  
        else:
            soco = ct_functions.sort_colliders(p.root_name)
            
        suffix_config = str(soco[1]).rjust(p.leading_zeroes, "0")
        name_config = "{}_{}".format(soco[0], suffix_config)
                    
        if act_obj.mode == 'EDIT':
            emode = upd_edit_mode(act_obj)
            ucp_radius = emode[0]
            ucp_z = emode[1]
            world_obj_center = emode[2]
            
#            print("Edit Mode: ucp_radius: ", ucp_radius)
#            print("Edit Mode: ucp_z: ", ucp_z)
#            print("Edit Mode: world_obj_center: ", world_obj_center)
    
        elif act_obj.mode == 'OBJECT':
            omode = upd_object_mode(act_obj)
            ucp_radius = omode[0]
            ucp_z = omode[1]
            world_obj_center = omode[2]
            
            if not omode == "FAIL":
                pass
#                print("Object Mode: Capsule Radius: ", ucp_radius)
#                print("Object Mode: Capsule Height(Z): ", ucp_z)
#                print("Object Mode: World Obj Center: ", world_obj_center)
            else:
                print()
                print("Unable to create Capsule Collider!")
                print("Tip:")
                print("Object's Z value must be greater than both X and Y values.")
                print("Try rebuilding Capsule in Edit Mode.\n")
                return

        
        bm = bmesh.new()
        bmesh.ops.create_uvsphere(bm, u_segments=12, v_segments=11, radius=ucp_radius)

        bm.verts.ensure_lookup_table()
        for vert in bm.verts:
            if vert.co[2] < 0:
                vert.co[2] -= ucp_z
            elif vert.co[2] > 0:
                vert.co[2] += ucp_z
                
        mesh = bpy.data.meshes.new(name_config)
        bm.to_mesh(mesh)
        mesh.update()
        bm.free()

        ucp_obj = bpy.data.objects.new(name_config, mesh)
        
        if p.option_parent_collider:
            ucp_obj.parent = act_obj
            ucp_obj.matrix_parent_inverse = act_obj.matrix_world.inverted()

        loc_act_obj = bpy.data.objects[act_obj.name].location
        rot_act_obj = bpy.data.objects[act_obj.name].rotation_euler
        #scale_act_obj = bpy.data.objects[act_obj.name].scale
        
        ucp_obj.location = world_obj_center
        #ucp_obj.location = loc_act_obj
        ucp_obj.rotation_euler = rot_act_obj
        #ucp_obj.scale = scale_act_obj
        
        if act_obj.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.context.scene.collection.children[p.collection_name].objects.link(ucp_obj)
        for so in bpy.context.view_layer.objects.selected:
            so.select_set(False)
        if p.select_created_collider:
            bpy.context.view_layer.objects.active = ucp_obj
            ucp_obj.select_set(True)
        else:
            bpy.context.view_layer.objects.active = ucp_obj
            act_obj.select_set(True)
        bpy.context.view_layer.update()
        bpy.context.view_layer.objects.active = ucp_obj
        ct_material.assign_material(ucp_obj)
        print()
        print("Capsule Collider Created\n")

        
    else:
        print("Unkown Error!  Something went wrong building Capsule!")

            
            
        
