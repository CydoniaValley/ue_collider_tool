import bpy
import re

pre = ("UBX_", "UCX_", "UCP_", "USP_")

# Check if the Collider Collection exists and create a new one if it doesn't
def check_collider_collection():
    p = bpy.context.scene.ct_props
    cc = bpy.data.collections.get(p.collection_name)
    if cc is None:
        new_c = bpy.data.collections.new(p.collection_name)
        bpy.context.scene.collection.children.link(new_c)
        
        # Set Collection dispay color to red. (Overwriteable)
        new_c.color_tag = 'COLOR_01'
        print("Created collider collection '{}'".format(new_c.name))
    else:
        cc = bpy.context.view_layer.layer_collection.children[p.collection_name]
        if cc.exclude == True:
            cc.exclude = False


def rename_current_material():
    #print("F_rename_current_material(s)")
    li = ['_A', '_B', '_C', '_D']
    p = bpy.context.scene.ct_props
    
    if len(p.material_name) > 0:
        for i in li:
            full_name = "{}{}".format(p.current_material, i)
            get_curr = bpy.data.materials.get(full_name)
            if get_curr is not None:
                get_curr.name = "{}{}".format(p.material_name, i)
                
        #print("F_rename_current_material: from: ", p.current_material, "  to: ", p.material_name)        
        p.current_material = p.material_name                            
    else:
        p.material_name = "INVALID ENTRY!"


# Change 'current_collection' to user selected input string 'collection_name'
def rename_current_collection():
    p = bpy.context.scene.ct_props
    if len(p.collection_name) > 0:
        print("FUNC_rename_current_collection: from: ", p.current_collection, "  to: ", p.collection_name)
        coll = bpy.data.collections.get(p.current_collection)
        p.current_collection = p.collection_name
        if coll:
            coll.name = p.collection_name
        # If No collection exists or was user-deleted, run function 'check_collider_collection')
        else:
            print("COLLECTION [", p.current_collection, "] DATA NOT FOUND!")
            print("Running check_collider_collection()")
            check_collider_collection()     
    else:
        p.collection_name = "INVALID ENTRY!"

        
def collate_colliders(lst):
    li_obj = []
    for o in bpy.data.objects:
        if o.name.startswith(pre):
            res = re.split('[_|.]', o.name)
            li_obj.append(res)
            
    li_sort = []
    for s in li_obj:
        li_substr = []
        for substr in s:
            if not substr.isdigit():  
                li_substr.append(substr)
        li_sort.append(li_substr)
                       
    li_colliders = []
    for i in li_sort:
        j = "_".join(i)
        lst.append(j)
    
    return lst
    

def finalize_sorted(lst):
    p = bpy.context.scene.ct_props
    lz = p.leading_zeroes
    le = len(lst)
    ct = 1
    idx = 0
    cur_idx = 0
    
    for i in lst:
        if le > ct:
            if lst[idx] == lst[idx +1]:
                _name = "{}_{}".format(lst[idx], str(cur_idx + 1).rjust(lz, "0"))
                lst[idx] = _name
                cur_idx += 1
            else:
                _name = "{}_{}".format(lst[idx], str(cur_idx + 1).rjust(lz, "0"))
                lst[idx] = _name
                cur_idx = 0
            ct += 1
            
        elif lst[idx] == lst[idx -1]:
            _name = "{}_{}".format(lst[idx], str(cur_idx + 1).rjust(lz, "0"))
            lst[idx] = _name
            cur_idx += 1
        else:
            _name = "{}_{}".format(lst[idx], str(cur_idx + 1).rjust(lz, "0"))
            lst[idx] = _name
            cur_idx = 0
   
        idx += 1
    return lst

def rename_colliders(lst):
    le = len(lst)
    idx = 0
    for o in bpy.data.objects:
        if o.name.startswith(pre):
            if le > idx:     
                o.name = "$!#--holder--#!$"
                o.data.name = "$!#--holder--#!$"
                idx += 1
                
    idx = 0
    for o in bpy.data.objects:
        if o.name.startswith("$!#--"):
            if le > idx:     
                o.name = lst[idx]
                o.data.name = lst[idx]
                idx += 1

def sort_colliders(act_obj_name):
    F_DEBUG = False
    p = bpy.context.scene.ct_props
    bmode = 0
    prefix = ""
    
    if p.build_mode == 0:
        if p.option_ubx:
            prefix = "UBX_"
        else: prefix = "UCX_"
    elif p.build_mode == 1:
        prefix = "UCX_"
    elif p.build_mode == 2:
        prefix = "UCP_"
    elif p.build_mode == 3:
        prefix = "USP_"
        
    li_colliders = []
    li_colliders = collate_colliders(li_colliders) 
    
    count = 0
    san_act_li = act_obj_name.rsplit(".", 1)
    sao_name = san_act_li[0]
    sao_prefix = "{}{}".format (prefix, sao_name)
    if sao_prefix in li_colliders:
        count = li_colliders.count(sao_prefix)  + 1 # add one to include the active object (act_obj)
    else:
        count = 1
    
    # print the results
    if F_DEBUG == True:
        print()
        print("  ---------------------------------\n")
        print("        *Sorted Collider Object Data*\n")
        print("    total colliders: ", len(li_colliders) + 1) ## add one to include the recently built collider
        print("    object (name): ", act_obj_name)
        print("    san_act_li (list): ", san_act_li)
        print("    act_obj_name (sao_prefix): ", sao_prefix)
        print("    count:", count)
        print("  ---------------------------------\n")
    
    # Execute local Functions
    li_colliders = finalize_sorted(li_colliders)
    rename_colliders(li_colliders)
    return sao_prefix, count


def sanitize_all_colliders():
    # Execute local Functions
    li_colliders = []
    li_colliders = collate_colliders(li_colliders)  
    li_colliders = finalize_sorted(li_colliders)
    rename_colliders(li_colliders)
    

def rename_all_colliders():
    print("* RENAME_ALL_COLLIDERS *")
    check_collider_collection()
    p = bpy.context.scene.ct_props
    if p.use_object_name_conv:
        ao = bpy.context.active_object
        rs = re.split('[_|.]', ao.name)
        newname = rs[0]
        print("Rename (Use Object):", newname)
    else:
        rs = re.split('[_|.]', p.root_name)
        newname = rs[0]
        print("Rename (Use Root):", newname)
        
    li_colliders = []
    li_colliders = collate_colliders(li_colliders)    
    li_addnewname = []
    
    for o in li_colliders:
        res = re.split('[_|.]', o)    
        name = "{}_{}".format(res[0], newname)
        li_addnewname.append(name)
    li_addnewname = finalize_sorted(li_addnewname)
    rename_colliders(li_addnewname)
    
def rename_selected_colliders():
    
    print("* RENAME_SELECTED_COLLIDERS *")
    check_collider_collection()
    p = bpy.context.scene.ct_props
    #so = bpy.context.selected_objects
    li_so = [obj.name for obj in bpy.context.selected_objects]
    print(li_so)
        
    if p.use_object_name_conv:
        ao = bpy.context.active_object
        sp_first = ao.name.split('_', 1)
        sp_second  = sp_first[1].rsplit('.',1)
        #sp_third  = sp_second[1].rsplit('_',1)
        print("sp_first", sp_first)
        print("sp_second", sp_second)
        newname = sp_second[0]
        print("Rename (Use Object):", newname)
    else:
        newname = p.root_name
        print("Rename (Use Root):", newname)
          
    li_addnewname = []
    i = 0            
    for o in bpy.context.selected_objects:
        if o.type == 'MESH' and o.name.startswith(pre):
            print(o.name)
            res = re.split('[_|.]', o.name)
            nname = "{}_{}_{}".format(res[0], newname, i)
            o.data.name = nname
            o.name = nname
            i += 1
            
    sanitize_all_colliders()
    