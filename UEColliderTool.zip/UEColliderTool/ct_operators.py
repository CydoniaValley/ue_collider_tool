import bpy

#Dev
# import ct_functions
# import ct_rectangle
# import ct_capsule
# import ct_sphere
# import ct_convex_hull

#Addon
from . import ct_functions
from . import ct_rectangle
from . import ct_capsule
from . import ct_sphere
from . import ct_convex_hull

#####      BUILD       #####

class CT_OT_BUILD(bpy.types.Operator):
    
    bl_label = "Build Collider"
    bl_idname = 'ct.build'
    bl_description = "Build Collider from selected Object."
    bl_options = {'REGISTER', 'UNDO'}
    

    @classmethod
    def poll(cls, context):
        p = context.scene.ct_props
        ao = context.active_object
        so = context.selected_objects
        pre = ("UBX_", "UCX_", "UCP_", "USP_")
        #hull_mode = False
#        if p.build_mode == 1:
#            hull_mode = len(so) > 0 and ao is not None and ao.type == 'MESH' and bpy.context.active_object.mode == 'OBJECT' and ao.name.startswith(pre)
#        else:
#            normal_mode = len(so) > 0 and ao is not None and ao.type == 'MESH' and ao.name.startswith(pre)
        #if ao: ex = ao.name.startswith(pre)
        if ao: ex = ao.name.startswith(pre)
        return len(so) > 0 and ao is not None and ao.type == 'MESH' and ex == False
        #return normal_mode == True or hull_mode == True
    
    def execute(self, context):
        p = context.scene.ct_props
        
        # Check if the Collider Collection exists and create it if necessary.
        ct_functions.check_collider_collection()
        
        # Build Rectangle
        if p.build_mode == 0:
            ct_rectangle.build_rectangle()
        elif p.build_mode == 2:
            ct_capsule.build_capsule()
        # Build Sphere
        elif p.build_mode == 3:
            ct_sphere.build_sphere()
        # Build Convex Hull
        elif p.build_mode == 1 and bpy.context.active_object.mode == 'OBJECT':
            ct_convex_hull.build_convex_hull()
            #convex_hull.duplicate_to_convexhull()
        else:
            print()
            self.report({'WARNING'}, "'Convex Hull' is only available in 'Object Mode'")
            print()
        return {'FINISHED'}


#####   TOOLS   #####


class CT_OT_RENAME_ALL_COLLIDERS(bpy.types.Operator):
    bl_label = "Rename All Colliders"
    bl_idname = 'ct.rename_all_colliders'
    bl_description = "Rename All Colliders"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        #p = context.scene.ct_props
        ao = context.active_object
        so = context.selected_objects
        pre = ("UBX_", "UCX_", "UCP_", "USP_")
        if ao:
            ex = ao.name.startswith(pre)
        return len(so) > 0 and ao is not None and ao.type == 'MESH' and ex == False

    
    def execute(self, context):
        ct_functions.rename_all_colliders()
        return {'FINISHED'}
    
    
class CT_OT_RENAME_SELECTED_COLLIDERS(bpy.types.Operator):
    bl_label = "Rename Selected Colliders"
    bl_idname = 'ct.rename_selected_colliders'
    bl_description = "Rename Selected Colliders"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        #p = context.scene.ct_props
        ao = context.active_object
        so = context.selected_objects
        pre = ("UBX_", "UCX_", "UCP_", "USP_")
        if ao:
            ex = ao.name.startswith(pre)
        return len(so) > 0 and ao is not None and ao.type == 'MESH' and ex == True

    
    def execute(self, context):
        ct_functions.rename_selected_colliders()
        return {'FINISHED'}

class CT_OT_SANITIZE_ALL_COLLIDERS(bpy.types.Operator):
    bl_label = "Sort and Sanitize All Colliders"
    bl_idname = 'ct.sanitize_all_colliders'
    bl_description = "Clean up and organize ALL collider names to better conform to UE collider pipeline."
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        ct_functions.sanitize_all_colliders()
        return {'FINISHED'}


#####    BUILD MODES   #####

class CT_OT_RECTANGLE_MODE(bpy.types.Operator):
    bl_label = "Rectangle (UCX or UBX)"
    bl_idname = 'ct.rectangle_mode'
    bl_description = "Rectangle Mode produces Symetrical rectangle shapes.  See the help menu or Offical UE website for more info."
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.build_mode = 0
        return {'FINISHED'}

class CT_OT_CONVEX_HULL_MODE(bpy.types.Operator):
    bl_label = "Convex Hull (UCX)"
    bl_idname = 'ct.convex_hull_mode'
    bl_description = "Convex Hull Mode can produce asymmetrical and non-uniformed shapes.  See the help menu or Offical UE website for more info."
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.build_mode = 1
        return {'FINISHED'}
    
class CT_OT_CAPSULE_MODE(bpy.types.Operator):
    bl_label = "Capsule (UCP)"
    bl_idname = 'ct.capsule_mode'
    bl_description = "Rectangle Mode produces Symetrical rectangle shapes.  See the help menu or Offical UE website for more info."
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.build_mode = 2
        return {'FINISHED'}
    
class CT_OT_SPHERE_MODE(bpy.types.Operator):
    bl_label = "Sphere (USP)"
    bl_idname = 'ct.sphere_mode'
    bl_description = "Sphere Mode produces a Sphere Collider*.  Sphere Collisions (and Box Collisions) have some limitations in UE.  See the help menu or Offical UE website for more info."
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.build_mode = 3
        return {'FINISHED'}

#####     HELP       #####

class CT_OT_HELP(bpy.types.Operator):
    bl_label = "v1.0 -- 2023          UE Collider Tool Help:"
    bl_idname = 'ct.help'
    bl_description = "Show Collider Tool Help"
    #bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.1
        box = layout.box()
        col = box.column()
        col.label(text="ABOUT:")
        col.label(text="")
        col.label(text="UE Collider Tool (UECT) was developed to simplify the process of creating, exporting and importing")
        col.label(text="Static Mesh Colliders into Unreal Engine 4 and 5.  UECT streamlines your workflow by keeping")
        col.label(text="colliders neatly organised and properly named in accordance to the UE collider pipeline.  This is")
        col.label(text="especially helpful for larger complex scenes with many meshes and colliders.  In addition, UECT may")
        col.label(text="be useful for creating and exporting Custom Colliders for UE’s Skeletal Meshes.")
        col.label(text="")
        col.label(text="Unlike some other collider creation tools, UECT doesn’t incorporate any fancy advanced algorithms to")
        col.label(text="create multiple colliders for complex object shapes with a single click.  Just about any collider you can ")
        col.label(text="create inside of UE, you can create with this addon.")
        col.label(text="")
        col.label(text="TIPS:")
        col.label(text="")
        col.label(text="1)  Open the 'System Console' to view logged details, tips, warnings, and errors.".upper())
        col.label(text="")
        col.label(text="2)  UECT attempts to correct scaling, but this not possible in all cases.  Check the Object's scaling")
        col.label(text="    if Collider's scaling is wrong.")
        col.label(text="")
        col.label(text="3)  Avoid using the underscore ‘_’ symbol for your object naming convention as this is counter-intuitive")
        col.label(text="    to UE collider naming pipeline.  (The object ‘My_Static_Mesh’ needs a collider named")
        col.label(text="    UCX_My_Static_Mesh_001, which is redundant and causes issues with UECT.)  The minus symbol")
        col.label(text="    (-)is acceptable and a good replacement.")
        col.label(text="")
        col.label(text="4)  Having a good understanding of Unreal Engine’s collider pipeline and naming conventions to avoid")
        col.label(text="    issues.  UE's mesh/collider naming conventions are rather strict and can be confusing for beginners.")
        col.label(text="    Read the offical docs at:")
        col.label(text="    'https://docs.unrealengine.com/5.2/en-US/fbx-static-mesh-pipeline-in-unreal-engine'")
        col.label(text="")
        col.label(text="5)  Avoid overlapping colliders.  Some users report issues with overlapping colliders not importing into UE.")
        col.label(text="    Even though many developers report having no issues at all with overlaps, it’s considered an inefficient")
        col.label(text="    practice")
        col.label(text="")

        
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=560)
    

##### ACTVIVE COLOR #####

class CT_OT_ACTIVE_COLOR_A(bpy.types.Operator):
    bl_label = ""
    bl_idname = 'ct.active_color_a'
    bl_description = "Pin/Unpin Active Color A"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.color_index = 0
        return {'FINISHED'}
    
class CT_OT_ACTIVE_COLOR_B(bpy.types.Operator):
    bl_label = ""
    bl_idname = 'ct.active_color_b'
    bl_description = "Pin/Unpin Active Color B"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.color_index = 1
        return {'FINISHED'}
    
class CT_OT_ACTIVE_COLOR_C(bpy.types.Operator):
    bl_label = ""
    bl_idname = 'ct.active_color_c'
    bl_description = "Pin/Unpin Active Color C"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.color_index = 2
        return {'FINISHED'}
    
class CT_OT_ACTIVE_COLOR_D(bpy.types.Operator):
    bl_label = ""
    bl_idname = 'ct.active_color_d'
    bl_description = "Pin/Unpin Active Color D"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.ct_props.color_index = 3
        return {'FINISHED'}
