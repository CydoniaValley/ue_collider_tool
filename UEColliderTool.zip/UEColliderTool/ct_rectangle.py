import bpy
import bmesh
#Dev
# import ct_functions
# import ct_material
#Addon
from . import ct_functions
from . import ct_material

def build_rectangle():
    
    print("\n* BUILD RECTANGLE *\n")
    act_obj = bpy.context.active_object
    # Make sure there is an object selected and it is a Mesh
    if act_obj is not None and act_obj.type == 'MESH':
        p = bpy.context.scene.ct_props
        
        # sort colliders based on user options selection
        if p.use_object_name_conv:
            soco = ct_functions.sort_colliders(act_obj.name)
        else:
            soco = ct_functions.sort_colliders(p.root_name)
            
        suffix_config = str(soco[1]).rjust(p.leading_zeroes, "0")
        name_config = "{}_{}".format(soco[0], suffix_config)
        
         
        lst_x = []
        lst_y = []
        lst_z = []
        verts = []
        faces = []
    
        if act_obj.mode == 'EDIT':
            bm = bmesh.new()
            bm = bmesh.from_edit_mesh(act_obj.data)
            for v in bm.verts:
                if v.select == True:
                    lst_x.append(v.co.x)
                    lst_y.append(v.co.y)
                    lst_z.append(v.co.z)
    
        elif act_obj.mode == 'OBJECT':
            vert_data = bpy.data.objects[act_obj.name].data
            for v in vert_data.vertices:
                lst_x.append(v.co.x)
                lst_y.append(v.co.y)
                lst_z.append(v.co.z)
        
        offset = p.collider_offset       
        min_x = min(lst_x) - offset
        max_x = max(lst_x) + offset
        min_y = min(lst_y) - offset
        max_y = max(lst_y) + offset
        min_z = min(lst_z) - offset
        max_z = max(lst_z) + offset
        

        min_size = 0.016
        if (max_x - min_x) < min_size:
            max_x = max_x + min_size
            min_x = min_x - min_size
        if (max_y - min_y) < min_size:
            max_y = max_y + min_size
            min_y = min_y - min_size
        if (max_z - min_z) < min_size:
            max_z = max_z + min_size
            min_z = min_z - min_size
        
        def vert(x,y,z):
            return x,y,z

        verts = [vert(max_x, max_y, min_z),
                 vert(max_x, min_y, min_z),
                 vert(min_x, min_y, min_z),
                 vert(min_x, max_y, min_z),
                 vert(max_x, max_y, max_z),
                 vert(max_x, min_y, max_z),
                 vert(min_x, min_y, max_z),
                 vert(min_x, max_y, max_z)]

        faces = [(0, 1, 2, 3),
                 (4, 7, 6, 5),
                 (0, 4, 5, 1),
                 (1, 5, 6, 2),
                 (2, 6, 7, 3),
                 (4, 0, 3, 7)]
        
        # Create a new mesh with above data and link them to the Collider Collection                      
        mesh = bpy.data.meshes.new(name_config)
        mesh.from_pydata(verts, [], faces)
        ucx_obj = bpy.data.objects.new(name_config, mesh)
    
        
        # Has the user selected to parent the Collider to the selected Object?
        if p.option_parent_collider:
            ucx_obj.parent = act_obj
            ucx_obj.matrix_parent_inverse = act_obj.matrix_world.inverted()
        # Get the Loc, Rot, and Scale of the Active Object
        loc_act_obj = bpy.data.objects[act_obj.name].location
        rot_act_obj = bpy.data.objects[act_obj.name].rotation_euler
        scale_act_obj = bpy.data.objects[act_obj.name].scale
        
        # Copy the Loc, Rot, and Scale from the original object
        ucx_obj.location = loc_act_obj
        ucx_obj.rotation_euler = rot_act_obj
        ucx_obj.scale = scale_act_obj
        
        # If in EDIT mode, switch to Object mode
        if act_obj.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.context.scene.collection.children[p.collection_name].objects.link(ucx_obj)
        
        #ucx_obj.parent = sel_obj
        #bpy.ops.object.select_all(action='DESELECT')
        for so in bpy.context.view_layer.objects.selected:
            so.select_set(False)
        
        if p.select_created_collider:
            bpy.context.view_layer.objects.active = ucx_obj
            ucx_obj.select_set(True)
        else:
            bpy.context.view_layer.objects.active = act_obj
            act_obj.select_set(True)
            
        bpy.context.view_layer.update()
        #ucx_obj.display_type = 'WIRE'
        
        bpy.context.view_layer.objects.active = ucx_obj
        ct_material.assign_material(ucx_obj)
        print("Rectangle (Box) Collider Created")
        
    else:
        print("Something went wrong building Rectangle!")