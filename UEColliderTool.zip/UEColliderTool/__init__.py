bl_info = {
    "name": "UE Collider Tool",
    "author": "Vega Draco",
    "version": (1, 0),
    "blender": (3, 6, 1),
    "location": "3D Viewport > Right Sidebar (N-Bar)",
    "description": "Create and organize Colliders (UCX, UBX, USP, UCP) for Unreal Engine",
    "warning": "This addon is currently in Beta and supplied 'As-Is'.  Always back up your files to avoid losing valuable time and work.",
    "doc_url": "",
    "category": "Unreal Engine Tools",
}


# import os
# import sys
#Addon
if "bpy" in locals():
   import importlib
   importlib.reload(ct_properties)
   importlib.reload(ct_operators)
   importlib.reload(ct_functions)
   importlib.reload(ct_material)
   importlib.reload(ct_rectangle)
   importlib.reload(ct_capsule)
   importlib.reload(ct_convex_hull)
   importlib.reload(ct_sphere)

else: 
   from . import ct_properties
   from . import ct_operators
   from . import ct_functions
   from . import ct_material
   from . import ct_rectangle
   from . import ct_capsule
   from . import ct_convex_hull
   from . import ct_sphere

      ## Developement ##
#____________________________#
import bpy
#del bpy.types.Scene.ct_props
#Dev
# dir = os.path.dirname(bpy.data.filepath)
# if not dir in sys.path:
    # sys.path.append(dir)    
# import ct_properties
# import ct_operators
# import ct_functions
# import ct_material
# import ct_rectangle
# import ct_capsule
# import ct_convex_hull
# import ct_sphere

# import imp
# imp.reload(ct_properties)
# imp.reload(ct_operators)
# imp.reload(ct_functions)
# imp.reload(ct_material)
# imp.reload(ct_rectangle)
# imp.reload(ct_capsule)
# imp.reload(ct_convex_hull)
# imp.reload(ct_sphere)


#print(bpy.path.display_name)
#print (bpy.path.display_name(name, *, has_ext=True, title_case=True))

#Dev
# def _clearconsole():
    # if os.name == "nt":
        # os.system("cls")
    # else:
        # os.system("clear")
# _clearconsole()


#____________________________#

print("* Using UE Collider Tool (v 1.0) *")


#print(bpy.data.filepath)

class CT_PT_COLLIDERTOOL(bpy.types.Panel):
    bl_label = "UE Collider Tool"
    bl_idname = "CT_PT_ColliderTool"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Collider Tool"
    
    def draw(self, context):
        layout = self.layout  
        scene = context.scene
        p = scene.ct_props
# SETTINGS     
        row=layout.row()
        row.scale_y = 1.1
        row.prop(p, 'tog_settings', toggle=True)
        if p.tog_settings:
            row = layout.row()
            row.label(text="Settings:")
            row.operator('ct.help', text="", icon='INFO')
            col = layout.column()
            col.prop(p, 'use_object_name_conv')
            col.prop(p, 'select_created_collider')
            col.prop(p, 'option_parent_collider')
            col.prop(p, 'option_ubx')
            #col.prop(p, 'option_capsule')
            #col.prop(p, 'option_sphere')

            row = layout.row()
            row.label(text="Collection Name:")
            row.scale_x = 1.25
            row.scale_y = 1.25
            row.prop(p, 'collection_name', icon='OUTLINER_COLLECTION')
            row = layout.row()
            row.label(text="Material Name:")
            row.scale_x = 1.25
            row.scale_y = 1.25
            row.prop(p, 'material_name', icon='MATERIAL_DATA')
            row=layout.row()
            row.label(text="Collider Root Name:")
            row.scale_x = 1.25
            row.scale_y = 1.25
            row.prop(p, 'root_name', icon='RIGID_BODY')
            row=layout.row()
            row.prop(p, 'leading_zeroes', text="Collider Leading Zeroes:")
            
            
# COLORS        
        row=layout.row()
        row.scale_y = 1.1
        row.prop(p, 'tog_colors', toggle=True)
        if p.tog_colors:
            col = layout.column()
            col.label(text="Collider Colors:")
            row = layout.row()
            if p.color_index == 0:
                row.operator('ct.active_color_a', icon='PINNED', text="", depress=True)
            else:
                row.operator('ct.active_color_a', icon='UNPINNED', text="", depress=False)
            #row.operator('ct.assign_color_a')
            row.prop(p, 'sel_color_a')
            row.prop(p, 'shader_opacity')
            row = layout.row()
            if p.color_index == 1:
                row.operator('ct.active_color_b', icon='PINNED', text="", depress=True)
            else:
                row.operator('ct.active_color_b', icon='UNPINNED', text="", depress=False)
            #row.operator('ct.assign_color_b')
            row.prop(p, 'sel_color_b')
            row.prop(p, 'shader_roughness')
            row=layout.row()
            if p.color_index == 2:
                row.operator('ct.active_color_c', icon='PINNED', text="", depress=True)
            else:
                row.operator('ct.active_color_c', icon='UNPINNED', text="", depress=False)
            #row.operator('ct.assign_color_c')
            row.prop(p, 'sel_color_c')
            row.prop(p, 'wireframe_size')
            row=layout.row()
            if p.color_index == 3:
                row.operator('ct.active_color_d', icon='PINNED', text="", depress=True)
            else:
                row.operator('ct.active_color_d', icon='UNPINNED', text="", depress=False)
            #row.operator('ct.assign_color_d')
            row.prop(p, 'sel_color_d')
            row.prop(p, 'shader_invert')
            
            row = layout.row()
            row.prop(p, 'shader_backface', toggle=True)
            row.prop(p, 'blend_mode')
        
        row=layout.row()
        #row=layout.row()
         
        #row=layout.row()
        box = layout.box()
        col = box.column()
        row = col.row()
        split = row.split(factor=0.125)
        col = split.column()
        col.scale_y = 2.4
        if p.use_object_name_conv:
            col.prop(p, 'use_object_name_conv', text="", icon='TRIA_DOWN')
        else:
            col.prop(p, 'use_object_name_conv', text="", icon='TRIA_UP')
        col = split.column()
        col.scale_y = 1.2        
        col.prop(p, 'root_name', icon='RIGID_BODY')
        col.template_ID(context.view_layer.objects, "active", filter='AVAILABLE')
        
        #row = layout.row()
        box = layout.box()
        col = box.column()
        if p.use_object_name_conv:
            col.operator('ct.rename_all_colliders', text="Rename All Colliders (ACTIVE OBJECT)")
            col.operator('ct.rename_selected_colliders', text="Rename Selected Colliders (ACTIVE OBJECT)")
        else:
            col.operator('ct.rename_all_colliders', text="Rename All Colliders (ROOT NAME)")
            col.operator('ct.rename_selected_colliders', text="Rename Selected Colliders (ROOT NAME)")    
        col.operator('ct.sanitize_all_colliders')
        col.scale_y = 1.25
        

        
        box = layout.box()
        col = box.column()
        col.scale_y = 1.75
        row = col.row()
        


        if p.build_mode == 2:
            row.operator('ct.capsule_mode', depress=True)
        else: row.operator('ct.capsule_mode', depress=False)
        #row = col.row()
        

        if p.build_mode == 3:
            row.operator('ct.sphere_mode', depress=True)
        else: row.operator('ct.sphere_mode', depress=False)
        
        row = col.row()
        row = col.row()
        if p.build_mode == 0:
            row.operator('ct.rectangle_mode', depress=True)
        else: row.operator('ct.rectangle_mode', depress=False)
        
        row = col.row()
        row = col.row()
        if p.build_mode == 1:
            row.operator('ct.convex_hull_mode', depress=True)  
            row = col.row()
            row.scale_y=0.75
            #row.prop(p,'create_dec_modifier')
            row.prop(p, 'decimate_rate')
            row = col.row()
            row.scale_y=0.5
            row.label(text = "Use Symmetry:")
            row = col.row(align = True)
            row.scale_y=0.75
            row.prop(p, 'x_hull_sym', toggle=True)
            row.prop(p, 'y_hull_sym', toggle=True)
            row.prop(p, 'z_hull_sym', toggle=True)
#        else:
#            row.prop(p, 'collider_offset')
            
            
        else: 
            row.operator('ct.convex_hull_mode', depress=False)
            box = layout.box()
            col = box.column()
            row = col.row()
            row.scale_y = 1.0
            row.prop(p, 'collider_offset')
        
        box = layout.box()
        col = box.column()
        row = col.row()
        row.scale_y = 3.0
        row.operator('ct.build')
        row = layout.row()
#        row = col.row()
#        row.separator()
#        row = col.row()
#        row.prop(p, 'collider_offset')
        


classes = [CT_PT_COLLIDERTOOL,
            ct_properties.CT_PROPERTIES,
            ct_operators.CT_OT_HELP,
            ct_operators.CT_OT_ACTIVE_COLOR_A,
            ct_operators.CT_OT_ACTIVE_COLOR_B,
            ct_operators.CT_OT_ACTIVE_COLOR_C,
            ct_operators.CT_OT_ACTIVE_COLOR_D,
            ct_operators.CT_OT_RECTANGLE_MODE,
            ct_operators.CT_OT_CONVEX_HULL_MODE,
            ct_operators.CT_OT_CAPSULE_MODE,
            ct_operators.CT_OT_SPHERE_MODE,
            ct_operators.CT_OT_BUILD,
            ct_operators.CT_OT_RENAME_ALL_COLLIDERS,
            ct_operators.CT_OT_RENAME_SELECTED_COLLIDERS,
            ct_operators.CT_OT_SANITIZE_ALL_COLLIDERS,
            ]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ct_props = bpy.props.PointerProperty(type=ct_properties.CT_PROPERTIES)
        
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.ct_props
    
if __name__ == '__main__':
    register()
