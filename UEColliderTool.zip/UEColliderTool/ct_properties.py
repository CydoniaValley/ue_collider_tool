import bpy

#Dev
# import ct_functions

#Addon
from . import ct_functions


##  Properties Updates

#def upd_build_mode(self, context):
#    p = context.scene.ct_props
#    #print("var: build_mode", p.build_mode)
#    
#def upd_tog_settings(self, context):
#    print("var: tog_settings")

#def upd_tog_colors(self, context):
#    print("var: tog_colors")

#def upd_tog_tools(self, context):
#    print("var: tog_tools")

def upd_collection_name(self, context):
    print("var: collection_name")
    #p = context.scene.ct_props
    ct_functions.rename_current_collection()

def upd_material_name(self, context):
    print("var: material_name")
    ct_functions.rename_current_material()
    
def upd_leading_zeroes(self, context):
    print("vars: leading_zeroes", p.leading_zeroes)

def upd_sel_color_a(self, context):
    p = bpy.context.scene.ct_props
    matname = "{}_A".format(p.material_name)
    if matname in bpy.data.materials:
        rgb = bpy.data.materials[matname].node_tree.nodes["RGB"]
        if rgb.label=="CT RGB": rgb.outputs[0].default_value = p.sel_color_a[:]

def upd_sel_color_b(self, context):
    p = bpy.context.scene.ct_props
    matname = "{}_B".format(p.material_name)
    if matname in bpy.data.materials:
        rgb = bpy.data.materials[matname].node_tree.nodes["RGB"]
        if rgb.label=="CT RGB": rgb.outputs[0].default_value = p.sel_color_b[:]

def upd_sel_color_c(self, context):
    p = bpy.context.scene.ct_props
    matname = "{}_C".format(p.material_name)
    if matname in bpy.data.materials:
        rgb = bpy.data.materials[matname].node_tree.nodes["RGB"]
        if rgb.label=="CT RGB": rgb.outputs[0].default_value = p.sel_color_c[:]
    
def upd_sel_color_d(self, context):
    p = bpy.context.scene.ct_props
    matname = "{}_D".format(p.material_name)
    if matname in bpy.data.materials:
        rgb = bpy.data.materials[matname].node_tree.nodes["RGB"]
        if rgb.label=="CT RGB": rgb.outputs[0].default_value = p.sel_color_d[:]
 
li = ['_A', '_B', '_C', '_D']
def upd_shader_opacity(self, context):
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            opacity = bpy.data.materials[matname].node_tree.nodes["Mix Shader"]
            if opacity.label=="CT Mix Shader":
                opacity.inputs[0].default_value = p.shader_opacity        
            
def upd_shader_roughness(self, context):
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            rough = bpy.data.materials[matname].node_tree.nodes["Glossy BSDF"]
            if rough.label=="CT Glossy BSDF":
                rough.inputs[1].default_value = p.shader_roughness

def upd_wireframe_size(self, context):
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            wire = bpy.data.materials[matname].node_tree.nodes["Wireframe"]
            if wire.label=="CT Wireframe":
                wire.inputs[0].default_value = p.wireframe_size
                
def upd_shader_invert(self, context):
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            invert = bpy.data.materials[matname].node_tree.nodes["Invert Color"]
            if invert.label=="CT Invert":
                invert.inputs[0].default_value = p.shader_invert
                
                
def upd_blend_mode(self, context):
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            bpy.data.materials[matname].blend_method = p.blend_mode
#        blend = bpy.data.materials[matname].blend_method
#        if blend == 
#            matname.blend_method = p.blend_mode
   
def upd_shader_backface(self, context):
    print("F_update_shader_backface")
    p = bpy.context.scene.ct_props
    for i in li:
        matname = "{}{}".format(p.material_name, i)
        if matname in bpy.data.materials:
            if p.shader_backface == True:
                bpy.data.materials[matname].show_transparent_back = True
            else:
                bpy.data.materials[matname].show_transparent_back = False
            #print(bpy.data.materials[matname].show_transparent_back)


        
def upd_x_hull_sym(self, context):
    print("X")
    p = bpy.context.scene.ct_props
    if p.x_hull_sym:
        p.y_hull_sym = False
        p.z_hull_sym = False

    
    
def upd_y_hull_sym(self, context):
    print("Y")
    p = bpy.context.scene.ct_props
    if p.y_hull_sym:
        p.x_hull_sym = False
        p.z_hull_sym = False
    
def upd_z_hull_sym(self, context):
    print("Z")
    p = bpy.context.scene.ct_props
    if p.z_hull_sym:
        p.x_hull_sym = False
        p.y_hull_sym = False


## Properties
class CT_PROPERTIES(bpy.types.PropertyGroup):
    
    ### BOOLEANS
    
        ## MENU
    tog_settings: bpy.props.BoolProperty(name="Settings",
                                        description="Collider Tool Settings.",
                                        default=True)
                                        #update=upd_tog_settings)
        ## MENU                            
    tog_colors: bpy.props.BoolProperty(name="Colors-Materials",
                                        description="Hide/Show Material and Color Settings",
                                        default=True)
                                        #update=upd_tog_colors)
        ## MENU                                
    tog_tools: bpy.props.BoolProperty(name="Tools",
                                        description="Tools",
                                        default=True)
                                        #update=upd_tog_tools)
                                        
    use_object_name_conv: bpy.props.BoolProperty(name="Name Colliders per Object instead of 'Collider Root Name'",
                                        description="Use the Object Name instead of the of the 'Collider Root' name",
                                        default=False)                                
                                        
    select_created_collider: bpy.props.BoolProperty(name="Select Collider after it's created",
                                        description="Choose whetherto make the Base Object or the Collider Object active after build",
                                        default=True)                                       

    option_parent_collider: bpy.props.BoolProperty(name="Auto-Parent Collider to Object",
                                        description="Parent Collider to the Base Object.  Useful when moving and scaling objects in the scene.",
                                        default=False)

    option_ubx: bpy.props.BoolProperty(name="Use UBX instead of UCX for Rectangles",
                                        description="Use UBX instead of UCX for Rectangular Shapes.  UBX, aka Rectangular or 'Box' Colliders have limitations in UE.  If in doubt, leave this setting unchecked.  See 'Help' for more info or vist Unreal Engine's official website.",
                                        default=True)
                                        
                                        
    shader_backface: bpy.props.BoolProperty(name="Show Backfaces",
                                        description="Show transparent backfaces",
                                        default=True,
                                        update=upd_shader_backface)
                                        
    use_symmetry: bpy.props.BoolProperty(name="Use Symmetry",
                                        description="Use Symmetry",
                                        default=False)
                                        
    
    x_hull_sym: bpy.props.BoolProperty(name="X",
                                    description="X Convex Hull Symmetry",
                                    default=False,
                                    update=upd_x_hull_sym)
                                    
    y_hull_sym: bpy.props.BoolProperty(name="Y",
                                    description="Y Convex Hull Symmetry",
                                    default=False,
                                    update=upd_y_hull_sym)
                                    
    z_hull_sym: bpy.props.BoolProperty(name="Z",
                                    description="Z Convex Hull Symmetry",
                                    default=False,
                                    update=upd_z_hull_sym)
                                    
    create_dec_modifier: bpy.props.BoolProperty(name="Create Decimate Modifier",
                                    description="Create Decimate Modifier or use preconfigured settings",
                                    default=False)
                                        
            

    ### INTEGER PROPERTIES
    
    build_mode: bpy.props.IntProperty(name="", default=0)
    
    color_index: bpy.props.IntProperty(name="", default=0)
    
    leading_zeroes: bpy.props.IntProperty(name="Leading Zeroes",
                                        description="Number of Leading Zeroes for Collider Suffix",
                                        min=1,
                                        max=5,
                                        default=3,
                                        update=upd_leading_zeroes)


    ### FLOAT PROPERTIES
    
    collider_offset: bpy.props.FloatProperty(name="Offset Amount:",
                                        description="Offset Amount",
                                        soft_min = -0.2, soft_max = 0.2,
                                        precision=3,
                                        step=0.1,
                                        default=0.01)
                                        
    shader_opacity: bpy.props.FloatProperty(name="Opacity:",
                                        description="Global Shader Opacity",
                                        min = 0.0,
                                        max = 1.0,
                                        precision=3,
                                        step=0.1,
                                        default=0.25,
                                        update=upd_shader_opacity)
                                        
    shader_roughness: bpy.props.FloatProperty(name="Roughness:",
                                        description="Global Shader Roughness",
                                        min = 0.0,
                                        max = 1.0,
                                        precision=3,
                                        step=0.1,
                                        default=0.25,
                                        update=upd_shader_roughness)
                                        
                                        
    wireframe_size: bpy.props.FloatProperty(name="Wireframe:",
                                        description="Wireframe Size",
                                        min = 0.0,
                                        max = 1.0,
                                        precision=3,
                                        step=0.1,
                                        default=0.02,
                                        update=upd_wireframe_size)
                                        
    shader_invert: bpy.props.FloatProperty(name="Invert:",
                                        description="Wireframe Size",
                                        min = 0.0,
                                        max = 1.0,
                                        precision=2,
                                        step=1.0,
                                        default=1.0,
                                        update=upd_shader_invert)
                                        
    decimate_rate: bpy.props.FloatProperty(name="Decimate Ratio:",
                                        description="Decimate Ratio",
                                        min = 0.01,
                                        max = 1.0,
                                        subtype='FACTOR',
                                        precision=2,
                                        step=1.0,
                                        default=0.5)      

                              
    ### STRINGS
    
    current_collection : bpy.props.StringProperty(name="" ,default="CT COLLIDERS")
    
    collection_name: bpy.props.StringProperty(name="",
                                        description="Name of Collection where all Colliders are stored.",
                                        maxlen=24,
                                        default="CT COLLIDERS",
                                        update=upd_collection_name)
    
    current_material: bpy.props.StringProperty(name="", default="CT MATERIAL") 
                                          
    material_name: bpy.props.StringProperty(name="",
                                        description="Base name for all 4 materials created by this add-on.",
                                        maxlen=24,
                                        default="CT MATERIAL",
                                        update=upd_material_name)
                                        
    root_name: bpy.props.StringProperty(name="",
                                        description="This is the 'Root Name' for the collider(s).  This text should be the same as your Object Name to be successfully imported into UE.  See 'Help' for more info.",
                                        maxlen=24,
                                        default="DefaultRootName",
                                        update=upd_material_name)
                                        
                      
    ### FLOAT VECTOR PROPERTIES
    
        ## COLORS
    
    sel_color_a: bpy.props.FloatVectorProperty(name="", description="Assign Color A", subtype='COLOR', size=4, min=0.0, max=1.0, default=(0.0, 1.0, 0.0, 1.0), update=upd_sel_color_a)
    sel_color_b: bpy.props.FloatVectorProperty(name="", description="Assign Color B", subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 1.0, 0.0, 1.0), update=upd_sel_color_b)
    sel_color_c: bpy.props.FloatVectorProperty(name="", description="Assign Color C", subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.25, 0.0, 1.0), update=upd_sel_color_c)
    sel_color_d: bpy.props.FloatVectorProperty(name="", description="Assign Color D", subtype='COLOR', size=4, min=0.0, max=1.0, default=(1.0, 0.0, 0.0, 1.0), update=upd_sel_color_d)
    
    
    
    ### ENUMERATOR PROPERTIES
    
    blend_mode: bpy.props.EnumProperty(name="",
                                        description="Change Blend Mode Setting",
                                        items = [
                                            ("OPAQUE", "Opaque", ""),
                                            ("CLIP", "Alpha Clip", ""),
                                            ("HASHED", "Alpha Hashed", ""),
                                            ("BLEND", "Alpha Blend", ""),
                                            ],
                                        default="BLEND",
                                        update=upd_blend_mode)
                                        